This project created for https://medium.com/ blog
1. Login to Instagram with Instagram API
2. Getting user info with Instagram API

Link:
https://medium.com/@1537877453702/instagram-api-simple-android-application-with-login-and-getting-user-info-e24f4f1bc023


Создание приложения подробно описано в моем блоге.
1. Вход пользователя в Инстаграм через ваше приложение.
2. Получение данных пользователя (имя пользователя, главное фото).

Ссылка на статью:
https://medium.com/@1537877453702/instagram-api-android-%D0%B2%D1%85%D0%BE%D0%B4-%D0%B8-%D0%BF%D0%BE%D0%BB%D1%83%D1%87%D0%B5%D0%BD%D0%B8%D0%B5-%D0%B4%D0%B0%D0%BD%D0%BD%D1%8B%D1%85-%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8F-3ebb448ebfc8
