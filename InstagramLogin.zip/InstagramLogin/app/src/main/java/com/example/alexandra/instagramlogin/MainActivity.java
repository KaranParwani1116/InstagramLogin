package com.example.alexandra.instagramlogin;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.alexandra.instagramlogin.models.AuthToken;
import com.example.alexandra.instagramlogin.models.Media;
import com.example.alexandra.instagramlogin.rest.Clients.MediaClient;
import com.example.alexandra.instagramlogin.rest.Clients.RestClient;
import com.example.alexandra.instagramlogin.rest.services.Auth;
import com.example.alexandra.instagramlogin.rest.services.MediaRequest;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.Map;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements AuthenticationListener {

    private static final String TAG = "MainActivity";
    private String token = null;
    private String code = null;
    private AppPreferences appPreferences = null;
    private AuthenticationDialog authenticationDialog = null;
    private Button button = null;
    private View info = null;
    AuthToken authToken = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = findViewById(R.id.btn_login);
        info = findViewById(R.id.info);
        appPreferences = new AppPreferences(this);

        //check already have access token
    }


    public void login() {
        button.setText("LOGOUT");
        info.setVisibility(View.VISIBLE);
        ImageView pic = findViewById(R.id.pic);
        Picasso.with(this).load(appPreferences.getString(AppPreferences.PROFILE_PIC)).into(pic);
        TextView id = findViewById(R.id.id);
        id.setText(appPreferences.getString(AppPreferences.USER_ID));
        TextView name = findViewById(R.id.name);
        name.setText(appPreferences.getString(AppPreferences.USER_NAME));
    }

    public void logout() {
        button.setText("INSTAGRAM LOGIN");
        token = null;
        info.setVisibility(View.GONE);
        appPreferences.clear();
    }

    @Override
    public void onTokenReceived(String auth_code) {
        Log.d(TAG, auth_code);
        appPreferences.putString(AppPreferences.CODE, auth_code);
        code = auth_code;

        getAccessToken(code);
    }

    //getting access token
    private void getAccessToken(final String code) {
        Auth auth = RestClient.getInstance();
        
        Call<AuthToken>authTokenCall = auth.getAuthToken(getString(R.string.client_id),getString(R.string.client_secret),"authorization_code",getString(R.string.redirect_url),
                code);


        authTokenCall.enqueue(new Callback<AuthToken>() {

            @Override
            public void onResponse(Call<AuthToken> call, Response<AuthToken> response) {
                Log.d(TAG, "onResponse: " + response.body().getAccessToken());

                RequestMedia(response.body());

            }

            @Override
            public void onFailure(Call<AuthToken> call, Throwable t) {
                Log.d(TAG, "onFailure: " + t.getMessage());
            }
        });

        Log.d(TAG, "getAccessToken: ");

    }

    public void onClick(View view) {
        if(token!=null)
        {
            logout();
        }
        else {
            authenticationDialog = new AuthenticationDialog(this, this);
            authenticationDialog.setCancelable(true);
            authenticationDialog.show();
        }
    }

    //hitting media api
    private void RequestMedia(AuthToken authToken)
    {
        String access_Token = authToken.getAccessToken();
        String user_id = authToken.getUserId();

        //building querymap
        Map<String,String> query = new HashMap<>();
        query.put("fields","media_url");
        query.put("access_token",access_Token);

        MediaRequest mediaRequest = MediaClient.getInstance();
        Call<Media>mediaCall = mediaRequest.getMedia(user_id,query);

        mediaCall.enqueue(new Callback<Media>() {
            @Override
            public void onResponse(Call<Media> call, Response<Media> response) {
                Log.d(TAG, "onResponse: media" + response.body().getData().get(0).getMediaUrl());
            }

            @Override
            public void onFailure(Call<Media> call, Throwable t) {
                Log.d(TAG, "onFailure: " + t.getMessage());
            }
        });

    }

}
