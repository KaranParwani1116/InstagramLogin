package com.example.alexandra.instagramlogin;

public interface AuthenticationListener {
    void onTokenReceived(String auth_token);
}
